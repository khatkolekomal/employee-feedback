import { Injectable } from '@angular/core';
import { Feedback } from './models/feedback';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  constructor() { }

  // public feedbackList: Subject<any[]>= new Subject<any[]>();
  public _feedback=new Subject<Feedback>();
  // public feedbackList:Feedback[];
  
  save(){  
    localStorage.setItem('','');
    localStorage.setItem('','');
  }

  public logout():void{
    localStorage.removeItem('');
    localStorage.removeItem('');    
  }

}
