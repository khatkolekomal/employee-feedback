import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { Feedback } from '../models/feedback';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { FeedbackService } from '../feedback.service';

 interface Project {
  value: string;
  viewValue: string;
}

interface Rating{
  value:string;
  viewValue:string;
}

@Component({
  selector: 'app-feedback-entry',
  templateUrl: './feedback-entry.component.html',
  styleUrls: ['./feedback-entry.component.css']
})
export class FeedbackEntryComponent implements OnInit {

  constructor(private _service:FeedbackService,private location:Location ) { 
    
  }

  eFeedback:Feedback;
  feedbackForm:FormGroup;

  projects: Project[] = [
  
    { value: '1', viewValue: 'Project-1' },
    { value: '2', viewValue: 'Project-2' },
    { value: '3', viewValue: 'Project-3' },
    { value: '4', viewValue: 'Project-4' },
  ];
  

  ratings: Rating []=[
    { value: '1', viewValue: '1' },
    { value: '2', viewValue: '2' },
    { value: '3', viewValue: '3' },
    { value: '4', viewValue: '4' },
  ]

  formControl = new FormControl('', [
    Validators.required
  ]);

  ngOnInit() {
    this.feedbackForm = new FormGroup({
      id:new FormControl('',[Validators.required,Validators.maxLength(20)]),
      name: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      project: new FormControl('',[Validators.required]),
      rating:new FormControl('',[Validators.required]),
      comment: new FormControl('', [Validators.required, Validators.maxLength(200)])
    });

    
  }
 
  public hasError = (controlName: string, errorName: string) =>{
    return this.feedbackForm.controls[controlName].hasError(errorName);
  }

  
  submit(feedbackForm:Feedback){   
    this._service._feedback.next(feedbackForm);
    

    this.feedbackForm.reset(this.feedbackForm.value);
  }

  public onCancel = () => {
    this.feedbackForm.reset(this.feedbackForm.value);
  }
 

  public confirmAdd(): void {
    
  }

}
