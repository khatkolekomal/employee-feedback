import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Feedback } from '../models/feedback';
import { MatTableDataSource } from '@angular/material/table';
import { FeedbackService } from '../feedback.service';

const feedbackList: Feedback[] = [
  {employeeId: '123', employeeName: 'Hydrogen',project:'',rating:1,comment:'azsdcfv'},
  {employeeId: '234', employeeName: 'oxygen',project:'',rating:2,comment:'azsdcfv'},

]

@Component({
  selector: 'app-feedback-list',
  templateUrl: './feedback-list.component.html',
  styleUrls: ['./feedback-list.component.css']
})
export class FeedbackListComponent implements OnInit {

  tableColumns: string[] = ['employeeName', 'rating', 'comment', 'action'];
  dataSource:Feedback[];
  showlist=false;

  constructor(private _service:FeedbackService,private cdr: ChangeDetectorRef) { 
    this._service._feedback.subscribe((value) => {
      this.showlist=false;
    if(!this.dataSource)
    this.dataSource=[];
    console.log(this.dataSource);
    this.dataSource.push(value);
    this.cdr.detectChanges();
    this.showlist=true;      
  });

  }

  
  ngOnInit(): void {
    
  }

  delete(x:number){
    var delBtn = confirm(" Do you want to delete ?");
    if ( delBtn == true ) {
      feedbackList.splice(x,1);
      this.dataSource.splice(x, 1 );  
      this.cdr.detectChanges();    
    }   
  } 

  edit(i:number,row:any){

  }
 
}
