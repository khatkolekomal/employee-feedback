export interface Feedback{
employeeId:string;
employeeName:string;
project:string;
rating:number;
comment:string;
}