import { Component, OnInit,ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { FeedbackService } from '../feedback.service';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit {

  constructor(private _service:FeedbackService,
    private router:Router,
    private fb:FormBuilder,
    private route:ActivatedRoute) {}

  ngOnInit(): void {
  }

  loginForm = this.fb.group({
    username: [null],
    password: [null]
  });

 

  onSubmit() {

    console.log(this.loginForm.value);

    if(this.loginForm.value.username=='user1234' && this.loginForm.value.password=='Password1')
    this.router.navigate(['/home']);
    else {

      alert('Username or Password are not correct.!');

    }

  }

}
