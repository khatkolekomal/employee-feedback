import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FeedbackListComponent } from './feedback-list/feedback-list.component';
import { FeedbackEntryComponent } from './feedback-entry/feedback-entry.component';


const routes: Routes = [

  {path:'',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'list',component:FeedbackListComponent},
  {path:'entry',component:FeedbackEntryComponent},
  {path:'**',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
